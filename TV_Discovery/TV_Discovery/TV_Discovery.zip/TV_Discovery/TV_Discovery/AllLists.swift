//
//  AllLists.swift
//  TV_Discovery
//
//  Created by iOSKurs on 30.11.16.
//  Copyright © 2016 iOSKurs. All rights reserved.
//

import Foundation

class AllLists{
    
    private var list : [ShowList] = []
    
}
